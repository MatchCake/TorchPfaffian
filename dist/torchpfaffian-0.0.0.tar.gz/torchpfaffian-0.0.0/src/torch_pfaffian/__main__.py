import argparse
import sys


def parse_args():
    paser = argparse.ArgumentParser()
    return paser.parse_args()


def main():
    pass


if __name__ == '__main__':
    sys.exit(main())
